package com.onsemi.cim.apps.exensioreftables.ws.model.lotg;

public enum Status {
    FOUND,
    NO_DATA
}
