-- related to ticket https://jira.onsemi.com/browse/CE-992

ALTER TABLE ON_FAB_CONF ADD SOURCELOT_ADJUSTMENT_PATTERN VARCHAR2(100);