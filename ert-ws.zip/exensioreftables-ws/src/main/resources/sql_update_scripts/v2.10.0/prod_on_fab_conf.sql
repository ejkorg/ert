update on_fab_conf set lotid_for_lotg = 'MFG_LOT', lotid_for_ltm = 'MFG_LOT'
where foundry_fab = 'JND:AIZU2 FAB (PTI)' and data_type = 'PROBE';