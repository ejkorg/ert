package com.onsemi.cim.apps.exensioreftables.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExensioRefTablesWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
