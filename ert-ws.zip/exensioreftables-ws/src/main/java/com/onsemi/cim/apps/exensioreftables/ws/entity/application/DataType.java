package com.onsemi.cim.apps.exensioreftables.ws.entity.application;

/**
 *
 * @author fg6zdy
 */
public enum DataType {
    STRING,
    NUMBER,
    BOOLEAN
}
