package com.onsemi.cim.apps.exensioreftables.ws.model.application;

/**
 * @author fg7ngj - Outericky, 6/21/2022
 */
public enum WaferIdSource {

    FROM_WS,
    CALCULATED,
    FROM_PCM_FILE,
    UNKNOWN
}
